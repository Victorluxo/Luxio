package com.luxio.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var status: TextView
    private var recognizer: SpeechRecognizer? = null
    private var listening = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
            setBackgroundColor(Color.rgb(5,7,13))
        }
        val title = TextView(this).apply {
            text = "LUXIO"
            textSize = 34f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "ASSISTENTE PESSOAL"
            textSize = 12f
            setTextColor(Color.rgb(145,135,255))
            gravity = Gravity.CENTER
        }
        val core = TextView(this).apply {
            text = "◉"
            textSize = 90f
            setTextColor(Color.rgb(138,124,255))
            gravity = Gravity.CENTER
            setPadding(0,40,0,40)
        }
        status = TextView(this).apply {
            text = "Toque no botão e diga: “Luxio, cheguei”"
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        val button = Button(this).apply {
            text = "🎙  FALAR"
            textSize = 16f
            setOnClickListener { startListening() }
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(core)
        root.addView(status)
        root.addView(button, LinearLayout.LayoutParams(-1, 60).apply { topMargin = 32 })
        setContentView(root)
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "Reconhecimento de voz indisponível neste celular."
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer!!.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { status.text = "Estou ouvindo..." }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { status.text = "Processando..." }
            override fun onError(error: Int) { status.text = "Não entendi. Toque novamente e tente falar." }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.lowercase(Locale.getDefault()) ?: ""
                handleCommand(text)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Fale com o Luxio")
        }
        recognizer!!.startListening(intent)
    }

    private fun handleCommand(text: String) {
        status.text = "Você disse: $text"
        when {
            text.contains("luxio") && text.contains("cheguei") -> status.text = "Olá! Luxio está pronto. 🚀"
            text.contains("youtube") -> openPackage("com.google.android.youtube", "YouTube")
            text.contains("configurações") || text.contains("configuração") ->
                startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
            else -> status.text = "Comando recebido. Em breve vou aprender mais comandos."
        }
    }

    private fun openPackage(pkg: String, name: String) {
        val launch = packageManager.getLaunchIntentForPackage(pkg)
        if (launch != null) startActivity(launch)
        else status.text = "$name não está instalado."
    }

    override fun onDestroy() {
        recognizer?.destroy()
        super.onDestroy()
    }
}
